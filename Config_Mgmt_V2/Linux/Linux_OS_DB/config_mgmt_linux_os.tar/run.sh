#!/bin/bash
#Author: John McCormack
#Date: 19/11/2012
#
#
HOST=`hostname`


### Easy way to run the colletion for Customers...
### Just get them to tun this file and collect the Tar file


cd config_mgmt/standalone_audit/
./collect.sh
cd ../../
tar -cf config_$HOST.tar config_mgmt
rm -rf config_mgmt
rm -rf config_mgmt_linux_os.tar
echo "######################################################"
echo ""
echo "Tar file config_$HOST.tar has been created"
echo "Please send this tar file back to Openet Support Team"
echo ""
echo "######################################################"
~


