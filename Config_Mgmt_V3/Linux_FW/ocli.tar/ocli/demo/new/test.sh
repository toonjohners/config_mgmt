#!/bin/bash
#Author: John McCormack
#Date: 19/11/2012
#
#





./alarm-management.sh  
./decision-tables.sh
./installation-management.sh  
./reference-data.sh      
./snmp-agent-management.sh  
./vcs-packages.sh
./applications.sh      
./edc-management.sh             
./logs.sh                     
./replication-system.sh  
./solution-modules.sh       
./web-applications.sh
./components.sh        
./external-network-elements.sh  
./parameter-management.sh     
./security.sh            
./statistics.sh
