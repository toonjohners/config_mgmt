#!/bin/sh
cd $FUSIONWORKS_PROD/bin
ocli() {
./ocli -x $SESSION_ID $@
}
trim() {
echo $1
}
CONN="connect Administrator/Openet01; cd configuration/components/CTE/"
SESSION_ID=$(trim `./ocli -g $CONN | cut -d":" -f2`)




for i in `ocli ls` ; do
	if [ -n $(trim $i) ] ; then
		config=`basename $i`
		ocli show $i > ~/ocli/cte/$config
	fi
		for x in `ocli ls /configuration/components/CTE/$i/collectors/` ; do
#			if [ -n $(trim $x) ] ; then
#				test=`basename $x`
#				ocli show $x > ~/ocli/cte/$test
			ocli ls $x
#			fi
done
done
