#!/bin/sh
cd $FUSIONWORKS_PROD/bin
ocli() {
./ocli -x $SESSION_ID $@
}
trim() {
echo $1
}
CONN="connect Administrator/Openet01; cd configuration/components/CTE"
SESSION_ID=$(trim `./ocli -g $CONN | cut -d":" -f2`)
for i in `ocli ls` ; do
if [ -n $(trim $i) ] ; then
#ocli set $i/Debug-Level-1 true
config=`basename $i`
#echo $i > ~/$config
ocli show $i > ~/$config
fi
done
